﻿namespace CH15DateClass
{

    class Program
    {
        static void Main(string[] args)
        {
            //Stuff goes here
            Console.WriteLine("Chapter 15 Date Class by James Sales\n");

            Console.WriteLine("Code is tested within the unit tests project");
            

            //End of program wait code
            Console.WriteLine("Press an any key to close. . .");
            Console.ReadKey();
        }
    }
}